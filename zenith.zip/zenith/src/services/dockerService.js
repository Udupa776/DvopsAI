import { exec, spawn } from 'child_process';
import util from 'util';

const execPromise = util.promisify(exec);

export class DockerService {
    constructor() {
        this.imageName = 'antigravity-sandbox';
    }

    async buildImage() {
        try {
            console.log(`[Docker] Building sandbox image ${this.imageName}...`);
            await execPromise(`docker build -t ${this.imageName} -f Dockerfile.sandbox .`);
            console.log(`[Docker] Sandbox image built.`);
        } catch (err) {
            console.error(`[Docker] Failed to build image:`, err);
        }
    }

    async createContainer(jobId) {
        const containerName = `sandbox-${jobId}`;
        try {
            // Run detached container that stays alive
            await execPromise(`docker run -d --name ${containerName} ${this.imageName}`);
            return containerName;
        } catch (error) {
            throw new Error(`Failed to create Docker container: ${error.message}`);
        }
    }

    async removeContainer(containerName) {
        try {
            await execPromise(`docker rm -f ${containerName}`);
        } catch (error) {
            console.error(`[Docker] Failed to remove container ${containerName}: ${error.message}`);
        }
    }

    async execInContainer(containerName, command) {
        return new Promise((resolve) => {
            const docker = spawn('docker', ['exec', '-i', containerName, 'bash']);

            let stdout = '';
            let stderr = '';

            docker.stdout.on('data', (data) => { stdout += data.toString(); });
            docker.stderr.on('data', (data) => { stderr += data.toString(); });

            docker.on('close', (code) => {
                resolve({ stdout, stderr, exitCode: code });
            });

            docker.on('error', (err) => {
                resolve({ stdout, stderr: stderr + err.message, exitCode: 1 });
            });

            // Write command directly to bash stdin, bypassing host shell escaping limits
            docker.stdin.write(command);
            docker.stdin.end();
        });
    }

    async cloneRepo(containerName, repoUrl) {
        // Clone inside container
        // Wipe target dir if exists to be safe
        const cmd = `rm -rf /sandbox/repo && git clone ${repoUrl} /sandbox/repo`;
        const result = await this.execInContainer(containerName, cmd);
        if (result.exitCode !== 0) {
            throw new Error(`Clone failed: ${result.stderr}`);
        }
    }

    async discoverAndRunTests(containerName) {
        // A script injected into container to discover and run frameworks
        const discoveryScript = `
      cd /sandbox/repo
      if [ -f "package.json" ]; then
        if grep -q '"jest"' package.json; then
          echo "FRAMEWORK_DETECTED: jest"
          npm install --silent
          npx jest --json 2>&1 || true
          exit 0
        elif grep -q '"mocha"' package.json; then
          echo "FRAMEWORK_DETECTED: mocha"
          npm install --silent
          npx mocha --reporter json 2>&1 || true
          exit 0
        else
          echo "FRAMEWORK_DETECTED: npm test"
          npm install --silent
          npm test 2>&1 || true
          exit 0
        fi
      elif [ -f "pytest.ini" ] || [ -f "setup.py" ] || [ -f "requirements.txt" ] || [ -d "tests" ] || ls test_*.py 1> /dev/null 2>&1; then
        echo "FRAMEWORK_DETECTED: pytest"
        if [ -f "requirements.txt" ]; then pip3 install -r requirements.txt; fi
        # Ensure pytest relies on json-report for structured output
        pytest --json-report || pytest
        exit 0
      fi
      
      echo "FRAMEWORK_DETECTED: unknown"
      exit 1
    `;

        return await this.execInContainer(containerName, discoveryScript);
    }
}

export const dockerService = new DockerService();

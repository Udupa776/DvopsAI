import dotenv from 'dotenv';
dotenv.config();

export class GithubService {
    constructor() {
        this.token = "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";
    }

    extractOwnerRepo(url) {
        // https://github.com/facebook/react -> { owner: 'facebook', repo: 'react' }
        // https://github.com/facebook/react.git -> { owner: 'facebook', repo: 'react' }
        const match = url.match(/github\.com\/([^\/]+)\/([^\/\.]+)/);
        if (!match) return null;
        return { owner: match[1], repo: match[2] };
    }

    async forkRepository(repoUrl) {
        if (!this.token) {
            console.warn("GITHUB_TOKEN is missing. Cannot fork.");
            return null;
        }

        const details = this.extractOwnerRepo(repoUrl);
        if (!details) {
            console.error(`Could not extract github owner and repo from ${repoUrl}`);
            return null;
        }

        console.log(`[GitHub API] Attempting to fork ${details.owner}/${details.repo}...`);

        try {
            // Create Fork API
            const response = await fetch(`https://api.github.com/repos/${details.owner}/${details.repo}/forks`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${this.token}`,
                    'Accept': 'application/vnd.github.v3+json',
                    'X-GitHub-Api-Version': '2022-11-28'
                }
            });

            if (!response.ok) {
                const errData = await response.json();
                console.error(`[GitHub API] Fork failed:`, errData);
                return null;
            }

            const data = await response.json();
            const forkedCloneUrl = data.clone_url;

            console.log(`[GitHub API] Fork successful. New repo: ${forkedCloneUrl}`);

            // Wait a moment for GitHub backend replica consistency if the fork is large
            await new Promise(r => setTimeout(r, 5000));

            return forkedCloneUrl;
        } catch (err) {
            console.error(`[GitHub API] Exception during fork flow:`, err);
            return null;
        }
    }

    getAuthenticatedCloneUrl(httpsUrl) {
        // https://github.com/MyUsername/react.git 
        // -> https://<token>@github.com/MyUsername/react.git
        if (!this.token || !httpsUrl) return httpsUrl;
        return httpsUrl.replace("https://", `https://${this.token}@`);
    }
}

export const githubService = new GithubService();
